/**
 * erp-common.js — Shared utilities for all SIP ERP pages
 */

// ─── CONFIGURATION ────────────────────────────────────────
const WEB_APP_URL = 'https://script.google.com/macros/s/AKfycbxG2SyCbRfZgRsUfaGL_VsCeErXV994ZxXvenaDHSH9LxchTcYfH1ROlMLxZy0IG-Kn/exec';

// ─── API HELPERS ──────────────────────────────────────────
// Global cache for API data to speed up SPA navigation
window.__erp_cache = {};

async function apiGet(params, useCache = false) {
    const qs = Object.entries(params).map(([k, v]) => k + '=' + encodeURIComponent(v)).join('&');
    const cacheKey = 'api_' + (params.action || 'default') + '_' + qs;

    // 1. Check in-memory cache first (for SPA speed)
    if (window.__erp_cache[cacheKey]) {
        const { data, timestamp } = window.__erp_cache[cacheKey];
        if (Date.now() - timestamp < 60000) return data; // 1 min in-memory
    }

    // 2. Check sessionStorage
    if (useCache) {
        const cached = sessionStorage.getItem(cacheKey);
        if (cached) {
            const { data, timestamp } = JSON.parse(cached);
            if (Date.now() - timestamp < 300000) { // 5 min cache
                window.__erp_cache[cacheKey] = { data, timestamp }; // Sync to memory
                return data;
            }
        }
    }

    const res = await fetch(WEB_APP_URL + '?' + qs);
    const data = await res.json();

    if (data.status === 'success') {
        window.__erp_cache[cacheKey] = { data, timestamp: Date.now() };
        if (useCache) sessionStorage.setItem(cacheKey, JSON.stringify({ data, timestamp: Date.now() }));
    }
    return data;
}

async function apiBatchGet(actions) {
    // 1. Check if all actions are available in cache
    let allCached = true;
    const batchResults = {};

    for (const act of actions) {
        // Build the same key as apiGet would use
        const params = { ...act };
        const qs = Object.entries(params).map(([k, v]) => k + '=' + encodeURIComponent(v)).join('&');
        const cacheKey = 'api_' + (params.action || 'default') + '_' + qs;

        if (window.__erp_cache[cacheKey] && (Date.now() - window.__erp_cache[cacheKey].timestamp < 60000)) {
            batchResults[act.action] = window.__erp_cache[cacheKey].data;
        } else {
            allCached = false;
            break;
        }
    }

    if (allCached) {
        return { status: 'success', data: batchResults, fromCache: true };
    }

    // 2. Fetch the batch from network
    const res = await apiPost({ action: 'batch', actions: actions });

    if (res && res.status === 'success' && res.data) {
        // 3. Store individual results back into the cache
        for (const act of actions) {
            const params = { ...act };
            const qs = Object.entries(params).map(([k, v]) => k + '=' + encodeURIComponent(v)).join('&');
            const cacheKey = 'api_' + (params.action || 'default') + '_' + qs;

            const actionResult = res.data[act.action];
            if (actionResult && actionResult.status === 'success') {
                window.__erp_cache[cacheKey] = {
                    data: actionResult,
                    timestamp: Date.now()
                };
            }
        }
    } else if (res && res.status === 'error' && res.message && res.message.includes('Unknown action: batch')) {
        showToast('CRITICAL: App Script not updated. Please deploy a New Version!', 'error');
        throw new Error('Google Apps Script needs to be re-deployed as a New Version.');
    }

    return res;
}

async function apiPost(payload) {
    const res = await fetch(WEB_APP_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain' },
        body: JSON.stringify(payload)
    });
    return res.json();
}

// ─── TOAST ────────────────────────────────────────────────
function showToast(message, type = 'info') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }
    const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', info: 'fa-info-circle', warning: 'fa-exclamation-triangle' };
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<i class="fa ${icons[type] || icons.info} toast-icon"></i><span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => { toast.style.opacity = '0'; toast.style.transform = 'translateX(110%)'; toast.style.transition = '.3s'; setTimeout(() => toast.remove(), 300); }, 3500);
}

// ─── CSV EXPORT ───────────────────────────────────────────
function exportCSV(data, filename) {
    if (!data || !data.length) { showToast('No data to export', 'warning'); return; }
    const headers = Object.keys(data[0]);
    let csv = headers.join(',') + '\n';
    data.forEach(row => {
        csv += headers.map(h => '"' + String(row[h] || '').replace(/"/g, '""') + '"').join(',') + '\n';
    });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    a.download = filename + '_' + new Date().toISOString().slice(0, 10) + '.csv';
    a.click();
}

// ─── PRINT ────────────────────────────────────────────────
function printTable(title) {
    const tableElement = document.querySelector('.erp-table');
    if (!tableElement) { showToast('No table found to print', 'warning'); return; }

    // Clone the table to avoid modifying the current view
    const clonedTable = tableElement.cloneNode(true);

    // Remove the 'Actions' column from the cloned table (both head and body)
    const headerRow = clonedTable.querySelector('thead tr');
    if (headerRow) {
        const lastTh = headerRow.lastElementChild;
        if (lastTh && lastTh.textContent.toLowerCase().includes('actions')) {
            lastTh.remove();
        }
    }

    clonedTable.querySelectorAll('tbody tr').forEach(row => {
        const lastTd = row.lastElementChild;
        // In our ERP, Actions is always the last column
        if (lastTd) lastTd.remove();
    });

    const userName = sessionStorage.getItem('userName') || sessionStorage.getItem('memberName') || 'Authorized User';

    const w = window.open('', '_blank');
    w.document.write(`<!DOCTYPE html><html><head><title>${title}</title>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700\u0026display=swap');
      body{font-family:'Inter', sans-serif;font-size:11px;padding:20px;color:#1e293b;background:#fff;display:block;}
      table{width:100%;border-collapse:collapse;margin-top:20px;table-layout:auto;}
      th,td{border:1px solid #e2e8f0;padding:10px 12px;text-align:left;vertical-align:top;word-wrap:break-word;}
      th{background:#f8fafc;font-weight:700;color:#475569;text-transform:uppercase;font-size:9px;letter-spacing:0.5px;white-space:nowrap;}
      .print-header{text-align:center;margin-bottom:20px;border-bottom:3px solid #0f172a;padding-bottom:20px;}
      .print-logo{height:60px;margin-bottom:12px;}
      .print-title{font-size:24px;font-weight:800;color:#0f172a;margin:0;letter-spacing:-0.5px;}
      .print-subtitle{font-size:14px;font-weight:600;color:#3b82f6;margin-top:8px;text-transform:uppercase;letter-spacing:1.5px;}
      .print-meta{margin-top:8px;font-size:10px;color:#64748b;}
      
      .print-footer{margin-top:30px;padding-top:20px;border-top:1px solid #e2e8f0;font-size:10px;color:#64748b;}
      .footer-row{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:8px;}
      .system-msg{font-style:italic;font-weight:600;color:#94a3b8;margin-top:15px;text-align:center;font-size:9px;}

      /* Badge Colors for Print */
      .badge{padding:3px 8px;border-radius:12px;font-size:8px;font-weight:700;text-transform:uppercase;display:inline-block;white-space:nowrap;}
      .badge-submitted{background:#eff6ff;color:#1e40af;border:1px solid #bfdbfe;}
      .badge-pending{background:#fefce8;color:#854d0e;border:1px solid #fef08a;}
      .badge-review{background:#fff7ed;color:#9a3412;border:1px solid #ffedd5;}
      .badge-approved, .badge-active{background:#f0fdf4;color:#166534;border:1px solid #bbf7d0;}
      .badge-rejected{background:#fef2f2;color:#991b1b;border:1px solid #fecaca;}
      .badge-published{background:#eef2ff;color:#3730a3;border:1px solid #e0e7ff;}
      .badge-hold{background:#f9fafb;color:#374151;border:1px solid #f3f4f6;}
      
      @media print {
        body { padding: 0; }
        @page { margin: 1.5cm; }
        .print-footer { position: fixed; bottom: 0; width: 100%; height: 80px; background: #fff; }
        table { page-break-inside: auto; }
        tr { page-break-inside: avoid; page-break-after: auto; }
        thead { display: table-header-group; }
      }
    </style></head><body>
    <div class="print-header">
      <img src="sip-logo.png" class="print-logo">
      <h1 class="print-title">Scholar India Publishers</h1>
      <div class="print-subtitle">${title}</div>
      <div class="print-meta">System Generated Report • ${new Date().toLocaleString()}</div>
    </div>
    <div style="margin-bottom:10px;font-size:10px;color:#64748b;font-weight:600;">Record Count: ${clonedTable.querySelectorAll('tbody tr').length}</div>
    ${clonedTable.outerHTML}
    
    <div class="print-footer">
      <div class="footer-row">
        <div><strong>Generated by:</strong> ${userName}</div>
        <div><strong>Print Date:</strong> ${new Date().toLocaleString('en-IN')}</div>
      </div>
      <div class="system-msg" style="margin-top:10px;text-align:center;">
        This is a system generated document. No signature is required.
      </div>
    </div>

    <script>window.onload=function(){setTimeout(()=>window.print(),500)}<\/script>
    </body></html>`);
    w.document.close();
}

// ─── ACTION MENUS ─────────────────────────────────────────
document.addEventListener('click', e => {
    if (!e.target.closest('.action-wrap')) {
        document.querySelectorAll('.action-menu.open').forEach(m => m.classList.remove('open'));
    }

    const sidebar = document.querySelector('.erp-sidebar');
    const toggleBtn = document.querySelector('.mobile-toggle');
    if (sidebar && sidebar.classList.contains('mobile-open')) {
        if (!sidebar.contains(e.target) && (!toggleBtn || !toggleBtn.contains(e.target))) {
            sidebar.classList.remove('mobile-open');
        }
    }
});

function toggleActionMenu(btn) {
    const menu = btn.nextElementSibling;
    const wasOpen = menu.classList.contains('open');
    document.querySelectorAll('.action-menu.open').forEach(m => m.classList.remove('open'));
    if (!wasOpen) menu.classList.add('open');
}

// ─── ACTIVITY LOGGING ─────────────────────────────────────
async function logActivity(actionType, details, page) {
    const uid = sessionStorage.getItem('userId') || sessionStorage.getItem('memberId');
    const uname = sessionStorage.getItem('userName') || sessionStorage.getItem('memberName');
    const role = sessionStorage.getItem('userRole') || sessionStorage.getItem('memberRole') || 'Unknown';
    try {
        await apiPost({ action: 'logActivity', action_type: actionType, userId: uid, userName: uname, role, details, page });
    } catch (e) { /* non-blocking */ }
}

// ─── UNREAD MESSAGE BADGE ─────────────────────────────────
async function refreshMessageBadge() {
    const uid = sessionStorage.getItem('userId') || sessionStorage.getItem('memberId') || 'admin';
    if (!uid) return;
    try {
        const res = await apiGet({ action: 'getMessages', userId: uid });
        renderMessageStatus(res);
    } catch (e) { }
}

function renderMessageStatus(res) {
    if (res.status === 'success') {
        const uid = sessionStorage.getItem('userId') || sessionStorage.getItem('memberId') || 'admin';
        const unread = res.data.filter(m => String(m['To']) === uid && String(m['Read']) !== 'true');
        const count = unread.length;
        document.querySelectorAll('.msg-badge').forEach(b => {
            b.textContent = count;
            b.classList.toggle('show', count > 0);
        });
        document.querySelectorAll('.bell-dot').forEach(d => d.classList.toggle('show', count > 0));
    }
}

// ─── POPUPS ───────────────────────────────────────────────
async function checkPopups() {
    const uid = sessionStorage.getItem('userId') || sessionStorage.getItem('memberId') || '';
    if (!uid) return;
    try {
        const res = await apiGet({ action: 'getPopups', userId: uid }, true); // Use cache
        renderPopups(res);
    } catch (e) { }
}

function renderPopups(res) {
    if (res.status === 'success' && res.data.length > 0) {
        const p = res.data[0]; // Show first active popup
        const banner = document.getElementById('popup-banner');
        if (banner) {
            banner.querySelector('.popup-title').textContent = p['Title'] || 'Notice';
            banner.querySelector('.popup-message').textContent = p['Message'] || '';
            banner.classList.add('show');
        }
    }
}

// ─── GLOBAL INIT ──────────────────────────────────────────
async function initGlobalData() {
    const uid = sessionStorage.getItem('userId') || sessionStorage.getItem('memberId') || 'admin';
    if (!uid) return;
    try {
        const res = await apiBatchGet([
            { action: 'getMessages', userId: uid },
            { action: 'getPopups', userId: uid }
        ]);
        if (res.status === 'success') {
            renderMessageStatus(res.data['getMessages']);
            renderPopups(res.data['getPopups']);
        }
    } catch (e) { }
}

function closePopup() {
    const banner = document.getElementById('popup-banner');
    if (banner) banner.classList.remove('show');
}

// ─── DATE FORMATTING ──────────────────────────────────────
function fmtDate(val) {
    if (!val) return '—';
    // If it's the "15/2/2026, 9:12:03 pm" format, try to clean it
    let cleanVal = String(val);
    if (cleanVal.includes(',') && cleanVal.includes('/')) {
        cleanVal = cleanVal.split(',')[0]; // Just take "15/2/2026"
        const parts = cleanVal.split('/');
        if (parts.length === 3) {
            // Re-order if needed or just try new Date(parts[2], parts[1]-1, parts[0])
            const d = new Date(parts[2], parts[1] - 1, parts[0]);
            if (!isNaN(d)) return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
        }
    }
    const d = new Date(val);
    return isNaN(d) ? String(val) : d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function fmtDT(val) {
    if (!val) return '—';
    const d = new Date(val);
    return isNaN(d) ? String(val) : d.toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

// ─── UTILITIES ────────────────────────────────────────────
function getVal(obj, patterns) {
    if (!obj) return '';
    const keys = Object.keys(obj);
    const trim = s => String(s).replace(/[^a-z0-9]/g, '').toLowerCase();
    const pReduced = patterns.map(trim);
    for (let p of pReduced) {
        const k = keys.find(key => trim(key).includes(p));
        if (k && obj[k] !== undefined && obj[k] !== null && String(obj[k]).trim() !== '') return String(obj[k]).trim();
    }
    return '';
}

// ─── STATUS BADGE ─────────────────────────────────────────
function statusBadge(status) {
    if (!status) return '<span class="badge badge-pending">—</span>';
    const s = String(status).toLowerCase().replace(/\s+/g, '-');
    const map = {
        'submitted': 'submitted', 'pending': 'pending',
        'under-review': 'review', 'under review': 'review',
        'accepted': 'accepted', 'approved': 'approved', 'active': 'active',
        'rejected': 'rejected', 'published': 'published',
        'hold': 'hold', 'completed': 'completed',
        'revoked': 'revoked', 'new': 'new', 'info': 'info'
    };
    const cls = map[s] || 'info';
    return `<span class="badge badge-${cls}">${status}</span>`;
}

// ─── SORT TABLE ───────────────────────────────────────────
let _sortState = {};
function sortTable(data, key, ascending) {
    return [...data].sort((a, b) => {
        const va = String(a[key] || '').toLowerCase();
        const vb = String(b[key] || '').toLowerCase();
        return ascending ? va.localeCompare(vb) : vb.localeCompare(va);
    });
}

// ─── SIDEBAR BUILDER ──────────────────────────────────────
function buildAdminSidebar(activePage) {
    const adminName = sessionStorage.getItem('userName') || 'Admin';
    const initials = adminName.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
    const items = [
        { section: 'REVIEW WORKFLOW' },
        { href: 'admin-approve-reviewers.html', icon: 'fa-user-check', label: 'Approve Reviewers', key: 'approve-reviewers' },
        { href: 'admin-assign.html', icon: 'fa-tasks', label: 'Assign Work', key: 'assign' },
        { href: 'admin-approve-reviews.html', icon: 'fa-clipboard-check', label: 'Approve Reviews', key: 'approve-reviews' },
        { href: 'admin-assignments.html', icon: 'fa-list-check', label: 'Assignments', key: 'assignments' },
        { section: 'CONTENT' },
        { href: 'admin-manuscripts.html', icon: 'fa-file-alt', label: 'Manuscripts', key: 'manuscripts' },
        { href: 'admin-final-submissions.html', icon: 'fa-file-signature', label: 'Final Submissions', key: 'final-submissions' },
        { href: 'admin-payments.html', icon: 'fa-credit-card', label: 'Payments', key: 'payments' },
        { href: 'admin-books.html', icon: 'fa-book', label: 'Books', key: 'books' },
        { href: 'admin-contact.html', icon: 'fa-envelope-open-text', label: 'Contact Leads', key: 'contact' },
        { href: 'admin-newsletter.html', icon: 'fa-newspaper', label: 'Newsletter', key: 'newsletter' },
    ];

    let html = `
  <aside class="erp-sidebar">
    <a href="admin-dashboard.html" class="sidebar-brand" style="text-decoration:none;">
      <img src="sip-logo.png" style="height:38px;width:38px;object-fit:contain;border-radius:8px;background:#fff;padding:2px;">
      <div class="sidebar-title">Scholar India<small>Admin Portal</small></div>
    </a>
    <nav class="sidebar-nav">`;

    items.forEach(item => {
        if (item.section) {
            html += `<div class="nav-section-label">${item.section}</div>`;
        } else {
            const isActive = activePage === item.key;
            html += `<a href="${item.href}" class="menu-item${isActive ? ' active' : ''}">
        <i class="fa ${item.icon}"></i>
        <span>${item.label}</span>
        <span class="menu-badge" id="badge-${item.key}" style="display:none;">0</span>
      </a>`;
        }
    });

    html += `</nav>
    <div class="sidebar-footer">
      <div style="font-size:10px;color:rgba(255,255,255,0.4);text-align:center;padding:10px;">Scholar India ERP v1.2</div>
    </div>
  </aside>
  <div id="popup-banner" class="popup-banner">
    <button class="popup-close-btn" onclick="closePopup()"><i class="fa fa-times"></i></button>
    <h4 class="popup-title">Notice</h4>
    <p class="popup-message"></p>
  </div>
  
  <!-- ADMIN PROFILE MODAL -->
  <div id="profileModal" class="modal-overlay">
    <div class="modal">
      <div class="modal-header">
        <h3><i class="fa fa-user-circle"></i> Profile Settings</h3>
        <button class="modal-close" onclick="closeModal('profileModal')">&times;</button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Full Name</label>
          <input type="text" id="profName" class="form-control">
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" id="profEmail" class="form-control" readonly style="background:#f1f5f9;">
        </div>
        <hr style="margin:20px 0;opacity:.1;">
        <div class="form-group">
          <label class="form-label">New Password</label>
          <input type="password" id="profPass" class="form-control" placeholder="Leave blank to keep current">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-gray" onclick="closeModal('profileModal')">Cancel</button>
        <button class="btn btn-primary" onclick="updateAdminProfile()">Save Changes</button>
      </div>
    </div>
  </div>`;

    document.body.insertAdjacentHTML('afterbegin', html);

    // Global Header Adjustments
    const headerLeft = document.querySelector('.header-left');
    if (headerLeft && !document.querySelector('.mobile-toggle')) {
        headerLeft.insertAdjacentHTML('afterbegin', `<button class="mobile-toggle" onclick="document.querySelector('.erp-sidebar').classList.toggle('mobile-open')"><i class="fa fa-bars"></i></button>`);
    }

    const headerRight = document.querySelector('.header-right');
    if (headerRight) {
        headerRight.innerHTML = `
            <a href="admin-performance.html" class="header-bell" title="Performance Statistics" style="background:#f0fdf4;color:#166534;">
                <i class="fa fa-chart-bar"></i>
            </a>
            <a href="admin-deadlines.html" class="header-bell" title="Deadline Calendar" style="background:#fffbeb;color:#92400e;">
                <i class="fa fa-calendar-alt"></i>
            </a>
            <a href="admin-login-activity.html" class="header-bell" title="Login Activity" style="background:#f8fafc;color:#475569;">
                <i class="fa fa-history"></i>
            </a>
            <div style="width:1px;height:24px;background:var(--border);margin:0 4px;"></div>
            <a href="admin-users.html" class="header-bell" title="Manage Users" style="background:var(--accent-bg);color:var(--accent);">
                <i class="fa fa-users"></i>
            </a>
            <a href="admin-popup.html" class="header-bell" title="Popup Messages" style="background:#fff7ed;color:#c2410c;">
                <i class="fa fa-bullhorn"></i>
            </a>
            <a href="admin-messages.html" class="header-bell" title="Messages">
                <i class="fa fa-bell"></i>
                <span class="bell-dot" id="global-bell"></span>
            </a>
            <div class="header-user" id="profile-trigger">
                <div class="user-avatar" id="header-avatar">${initials}</div>
                <div class="user-info">
                    <div class="user-name" id="header-user-name">${adminName}</div>
                    <div class="user-role">Administrator</div>
                </div>
                <div class="user-dropdown">
                    <button onclick="navigateTo('admin-users.html')"><i class="fa fa-cog"></i> Profile Settings</button>
                    <div class="separator"></div>
                    <button onclick="if(confirm('Logout?')){sessionStorage.clear();window.location.href='admin-login.html';}" style="color:var(--danger);">
                        <i class="fa fa-sign-out-alt"></i> Logout
                    </button>
                </div>
            </div>
        `;

        // Handle trigger
        const trigger = document.getElementById('profile-trigger');
        trigger.onclick = (e) => {
            if (e.target.closest('button')) return;
            trigger.classList.toggle('active');
        };
        document.addEventListener('click', e => {
            if (!e.target.closest('#profile-trigger')) trigger.classList.remove('active');
        });
    }

    // Start global init
    initGlobalData();
    refreshNotificationBadges();
    setInterval(refreshMessageBadge, 20000);
    setInterval(refreshNotificationBadges, 30000);
}

async function refreshNotificationBadges() {
    try {
        const res = await apiBatchGet([
            { action: 'getManuscripts' },
            { action: 'getPayments' },
            { action: 'getBooks' },
            { action: 'getContact' },
            { action: 'getNewsletter' }
        ]);
        if (res.status === 'success') {
            const data = res.data;

            // New Manuscripts (Read != Yes)
            const newMs = (data['getManuscripts'].data || []).filter(m => (m['Read'] || 'No') !== 'Yes').length;
            updateBadge('badge-manuscripts', newMs);

            // New Payments (Read != Yes)
            const newPm = (data['getPayments'].data || []).filter(p => (p['Read'] || 'No') !== 'Yes').length;
            updateBadge('badge-payments', newPm);

            // New Books (Read != Yes)
            const newBk = (data['getBooks'].data || []).filter(b => (b['Read'] || 'No') !== 'Yes').length;
            updateBadge('badge-books', newBk);

            // New Contacts (Make as Read != Yes)
            const newCt = (data['getContact'].data || []).filter(c => (c['Make as Read'] || 'No') !== 'Yes').length;
            updateBadge('badge-contact', newCt);

            // New Newsletter (Read != Yes)
            const newNl = (data['getNewsletter']?.data || []).filter(n => (n['Read'] || 'No') !== 'Yes').length;
            updateBadge('badge-newsletter', newNl);
        }
    } catch (e) { console.error('Badge refresh failed', e); }
}

function updateBadge(id, count) {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = count > 99 ? '99+' : count;
    el.style.display = count > 0 ? 'inline-block' : 'none';
    if (count > 0) el.classList.add('badge-new-anim');
}

function openProfileModal() {
    document.getElementById('profName').value = sessionStorage.getItem('userName') || 'Admin';
    document.getElementById('profEmail').value = sessionStorage.getItem('userEmail') || 'admin@scholarindia.com';
    document.getElementById('profPass').value = '';
    document.getElementById('profileModal').classList.add('show');
}

async function updateAdminProfile() {
    const name = document.getElementById('profName').value;
    const pass = document.getElementById('profPass').value;
    const email = document.getElementById('profEmail').value;

    if (!name) return showToast('Name is required', 'error');

    const updates = { 'First Name': name.split(' ')[0], 'Last Name': name.split(' ').slice(1).join(' ') };
    if (pass) updates['Password'] = pass;

    const res = await apiPost({ action: 'updateStatus', sheetName: 'Reviewers', idColumn: 'Email', idValue: email, updates: updates });
    if (res.status === 'success') {
        showToast('✓ Profile updated', 'success');
        sessionStorage.setItem('userName', name);
        closeModal('profileModal');
        setTimeout(() => location.reload(), 1000);
    } else {
        showToast('Error: ' + res.message, 'error');
    }
}

function closeModal(id) { document.getElementById(id).classList.remove('show'); }

function buildMemberSidebar(activePage) {
    const memberName = sessionStorage.getItem('memberName') || 'Member';
    const memberRole = sessionStorage.getItem('memberRole') || 'Reviewer';
    const initials = memberName.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
    const items = [
        { href: 'member-dashboard.html', icon: 'fa-home', label: 'Dashboard', key: 'dashboard' },
        { href: 'member-manuscripts.html', icon: 'fa-file-alt', label: 'Manuscripts', key: 'manuscripts' },
        { href: 'member-submit-review.html', icon: 'fa-edit', label: 'Submit Review', key: 'review' },
        { href: 'member-performance.html', icon: 'fa-chart-line', label: 'Performance', key: 'performance' },
        { href: 'member-deadlines.html', icon: 'fa-calendar-alt', label: 'Deadlines', key: 'deadlines' },
        { href: 'member-messages.html', icon: 'fa-comments', label: 'Messages', key: 'messages', badge: true },
    ];

    let html = `
  <aside class="erp-sidebar">
    <div class="sidebar-brand">
      <img src="sip-logo.png" style="height:38px;width:38px;object-fit:contain;border-radius:8px;background:#fff;padding:2px;">
      <div class="sidebar-title">Scholar India<small>${memberRole} Portal</small></div>
    </div>
    <nav class="sidebar-nav">`;

    items.forEach(item => {
        const isActive = activePage === item.key;
        html += `<a href="${item.href}" class="menu-item${isActive ? ' active' : ''}">
      <i class="fa ${item.icon}"></i>
      <span>${item.label}</span>
      ${item.badge ? '<span class="menu-badge msg-badge" id="msg-badge-nav">0</span>' : ''}
    </a>`;
    });

    html += `</nav>
    <div class="sidebar-footer">
      <a href="#" class="menu-item" onclick="if(confirm('Logout?')){sessionStorage.clear();window.location.href='member-login.html';}">
        <i class="fa fa-sign-out-alt"></i><span>Logout</span>
      </a>
    </div>
  </aside>
  <div id="popup-banner" class="popup-banner">
    <button class="popup-close-btn" onclick="closePopup()"><i class="fa fa-times"></i></button>
    <h4 class="popup-title">Notice</h4>
    <p class="popup-message"></p>
  </div>`;

    document.body.insertAdjacentHTML('afterbegin', html);

    const headerLeft = document.querySelector('.header-left');
    if (headerLeft && !document.querySelector('.mobile-toggle')) {
        headerLeft.insertAdjacentHTML('afterbegin', `<button class="mobile-toggle" onclick="document.querySelector('.erp-sidebar').classList.toggle('mobile-open')"><i class="fa fa-bars"></i></button>`);
    }

    const headerUser = document.getElementById('header-user-name');
    if (headerUser) headerUser.textContent = memberName;
    const headerAvatar = document.getElementById('header-avatar');
    if (headerAvatar) headerAvatar.textContent = initials;

    const memberId = sessionStorage.getItem('memberId');
    if (memberId) {
        initGlobalData();
        setInterval(() => refreshMessageBadge(), 20000);
    }
}

// ─── SPA NAVIGATION ENGINE ────────────────────────────────
let _isNavigating = false;
const _prefetchCache = {};

async function prefetchPage(url) {
    if (_prefetchCache[url] || _isNavigating) return;
    try {
        const res = await fetch(url);
        if (res.ok) _prefetchCache[url] = await res.text();
    } catch (e) { }
}

async function navigateTo(url, push = true) {
    if (_isNavigating) return;

    // Normalize URL
    if (!url.includes('.html') && !url.includes('://') && !url.startsWith('#')) {
        url = url + '.html';
    }

    _isNavigating = true;
    startProgress();

    try {
        let html = _prefetchCache[url];
        if (!html) {
            const res = await fetch(url);
            if (!res.ok) throw new Error('Page load failed');
            html = await res.text();
        }

        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');

        // 1. Swapping Content
        const newContent = doc.querySelector('.erp-content');
        const oldContent = document.querySelector('.erp-content');

        // If the target page isn't part of the ERP layout (like login), fallback to full reload
        if (!newContent) {
            window.location.href = url;
            return;
        }

        // 2. Update Title
        document.title = doc.title;

        if (newContent && oldContent) {
            // Pre-caching logic: If we already have data for the new page, it will load even faster
            oldContent.innerHTML = newContent.innerHTML;
            oldContent.classList.remove('spa-fade-in');
            void oldContent.offsetWidth; // trigger reflow
            oldContent.classList.add('spa-fade-in');
            // Scroll to top
            oldContent.scrollTop = 0;

            // If the new page has a spinner or loading row, the cache will likely 
            // fill it so fast the user won't even see it.
        }

        // 3. Update Header Title
        const newHT = doc.querySelector('.header-title');
        const oldHT = document.querySelector('.header-title');
        if (newHT && oldHT) oldHT.textContent = newHT.textContent;

        const newHB = doc.querySelector('.header-breadcrumb');
        const oldHB = document.querySelector('.header-breadcrumb');
        if (newHB && oldHB) oldHB.innerHTML = newHB.innerHTML;

        // 4. Update Sidebar Active State
        document.querySelectorAll('.menu-item').forEach(item => {
            const href = item.getAttribute('href');
            item.classList.toggle('active', href === url || href === url.split('/').pop());
        });

        // 5. Update URL
        if (push) history.pushState({ url }, '', url);

        // 6. EXECUTE SCRIPTS
        // We look for any inline scripts or page-specific logic
        const scripts = doc.querySelectorAll('script');
        scripts.forEach(s => {
            if (s.src && !s.src.includes('erp-common.js')) {
                // External script (rare in this ERP)
                const newS = document.createElement('script');
                newS.src = s.src;
                document.body.appendChild(newS);
            } else if (!s.src && s.textContent.trim()) {
                // Inline script (This is where most page logic resides)
                try {
                    // We avoid re-running sidebar builders but we NEED loadData/loadDashboard
                    let code = s.textContent.replace(/buildAdminSidebar\(.*?\);/g, '')
                        .replace(/buildMemberSidebar\(.*?\);/g, '');

                    // CRITICAL: We replace 'let ' and 'const ' with 'var ' inside these page scripts
                    // so that re-navigating to the same page or pages with same-named variables
                    // doesn't trigger "Identifier already declared" errors in the global scope.
                    code = code.replace(/\blet\s+/g, 'var ').replace(/\bconst\s+/g, 'var ');

                    eval(code);
                } catch (e) {
                    console.error('SPA Script Exec Error:', e);
                }
            }
        });

    } catch (err) {
        console.error('Navigation failed:', err);
        window.location.href = url; // Fallback to traditional load
    } finally {
        finishProgress();
        _isNavigating = false;
    }
}

// ─── PROGRESS BAR ─────────────────────────────────────────
function startProgress() {
    let bar = document.getElementById('nprogress');
    if (!bar) {
        bar = document.createElement('div');
        bar.id = 'nprogress';
        bar.innerHTML = '<div class="bar"><div class="peg"></div></div>';
        document.body.appendChild(bar);
    }
    const el = bar.querySelector('.bar');
    el.style.width = '0%';
    el.style.opacity = '1';
    el.style.display = 'block';
    setTimeout(() => { el.style.width = '30%'; }, 50);
    setTimeout(() => { if (_isNavigating) el.style.width = '70%'; }, 500);
}

function finishProgress() {
    const bar = document.getElementById('nprogress');
    if (!bar) return;
    const el = bar.querySelector('.bar');
    el.style.width = '100%';
    setTimeout(() => {
        el.style.opacity = '0';
        setTimeout(() => { el.style.display = 'none'; }, 300);
    }, 200);
}

// ─── EVENT INTERCEPTION ───────────────────────────────────
document.addEventListener('click', e => {
    const link = e.target.closest('a');
    if (!link) return;

    const href = link.getAttribute('href');
    if (!href || href.startsWith('http') || href.startsWith('#') || href.startsWith('mailto:') || href.startsWith('javascript:')) return;

    // Check if it's an internal HTML link
    if (href.includes('.html') || !href.includes('.')) {
        e.preventDefault();
        navigateTo(href);
    }
});

let _hoverTimer;
document.addEventListener('mouseover', e => {
    const link = e.target.closest('a');
    if (!link) return;
    const href = link.getAttribute('href');
    if (href && (href.includes('.html') || !href.includes('.')) && !href.startsWith('http')) {
        clearTimeout(_hoverTimer);
        _hoverTimer = setTimeout(() => prefetchPage(href), 100);
    }
});

window.addEventListener('popstate', e => {
    if (e.state && e.state.url) {
        navigateTo(e.state.url, false);
    } else {
        // Fallback for initial page or non-state navigation
        window.location.reload();
    }
});

// ─── VISUAL URL RENAME (Remove .html) ─────────────────────
window.addEventListener('DOMContentLoaded', () => {
    if (window.location.protocol !== 'file:') {
        const path = window.location.pathname;
        if (path.endsWith('.html')) {
            const cleanPath = path.slice(0, -5);
            window.history.replaceState({ url: path.split('/').pop() }, '', cleanPath + window.location.search + window.location.hash);
        }
    }
});
